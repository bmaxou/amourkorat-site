(function(){
"use strict";
var R=document.documentElement, ROOT=R.getAttribute('data-root')||'./';
function ls(k,v){try{if(v===undefined)return localStorage.getItem(k);localStorage.setItem(k,v)}catch(e){return null}}
function $(s,c){return (c||document).querySelector(s)}
function $$(s,c){return Array.prototype.slice.call((c||document).querySelectorAll(s))}
function norm(s){return (s||'').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,'')}

/* Thème et loupe */
function setTheme(t){if(t==='auto'){R.removeAttribute('data-theme')}else{R.setAttribute('data-theme',t)}ls('ak-theme',t);$$('[data-theme-set]').forEach(function(b){b.setAttribute('aria-pressed',b.getAttribute('data-theme-set')===t)})}
function setScale(s){s=Math.max(.85,Math.min(1.45,s));R.style.setProperty('--scale',s);ls('ak-scale',String(s));var o=$('#scale-val');if(o)o.textContent=Math.round(s*100)+' %'}
setTheme(ls('ak-theme')||'auto');setScale(parseFloat(ls('ak-scale'))||1);
$$('[data-theme-set]').forEach(function(b){b.addEventListener('click',function(){setTheme(b.getAttribute('data-theme-set'))})});
$$('[data-scale]').forEach(function(b){b.addEventListener('click',function(){var d=b.getAttribute('data-scale');var cur=parseFloat(getComputedStyle(R).getPropertyValue('--scale'))||1;setScale(d==='0'?1:cur+parseFloat(d))})});

/* Panneaux */
function toggle(id,btn){var p=document.getElementById(id);if(!p)return;var o=!p.classList.contains('open');$$('.panel.open').forEach(function(x){x.classList.remove('open')});if(o)p.classList.add('open');if(btn)btn.setAttribute('aria-expanded',o)}
$$('[data-panel]').forEach(function(b){b.addEventListener('click',function(e){e.stopPropagation();toggle(b.getAttribute('data-panel'),b)})});
document.addEventListener('click',function(e){if(!e.target.closest('.panel'))$$('.panel.open').forEach(function(x){x.classList.remove('open')})});
var mb=$('.menu-btn'),nav=$('.nav');if(mb&&nav)mb.addEventListener('click',function(){nav.classList.toggle('open');mb.setAttribute('aria-expanded',nav.classList.contains('open'))});
$$('.dd>button').forEach(function(b){b.addEventListener('click',function(e){e.preventDefault();var d=b.parentNode;var o=!d.classList.contains('open');$$('.dd.open').forEach(function(x){x.classList.remove('open')});if(o)d.classList.add('open')})});

/* Traduction Google : chargée à la demande */
var tr=false;window.googleTranslateElementInit=function(){new google.translate.TranslateElement({pageLanguage:'fr',autoDisplay:false},'google_translate_element')};
$$('[data-panel="p-lang"]').forEach(function(b){b.addEventListener('click',function(){if(tr)return;tr=true;var s=document.createElement('script');s.src='https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit';document.body.appendChild(s)})});

/* Progression, retour en haut, apparition */
var pg=$('#progress'),tt=$('.totop');
function onScroll(){var h=R.scrollHeight-R.clientHeight;if(pg)pg.style.width=(h>0?(R.scrollTop||document.body.scrollTop)/h*100:0)+'%';if(tt)tt.classList.toggle('show',(window.scrollY||0)>700)}
window.addEventListener('scroll',onScroll,{passive:true});onScroll();
if(tt)tt.addEventListener('click',function(){window.scrollTo({top:0,behavior:'smooth'})});
if('IntersectionObserver' in window){var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}})},{rootMargin:'0px 0px -60px 0px'});$$('.reveal').forEach(function(el){io.observe(el)})}else{$$('.reveal').forEach(function(el){el.classList.add('in')})}

/* Visionneuse avec loupe */
var lb=document.createElement('div');lb.id='lb';lb.innerHTML='<button aria-label="Fermer">&times;</button><img alt="">';document.body.appendChild(lb);
var lbi=$('img',lb);
$$('.prose img, .gal img, .fiche img, img.zoom').forEach(function(im){im.addEventListener('click',function(){lbi.src=im.getAttribute('data-full')||im.currentSrc||im.src;lbi.alt=im.alt;lbi.classList.remove('z');lb.classList.add('open')})});
lbi.addEventListener('click',function(e){e.stopPropagation();lbi.classList.toggle('z')});
lb.addEventListener('click',function(){lb.classList.remove('open')});
document.addEventListener('keydown',function(e){if(e.key==='Escape'){lb.classList.remove('open');closeSearch()}});

/* Glossaire : info-bulles */
var tip=null;
$$('a.gl').forEach(function(a){
  function show(){hide();tip=document.createElement('div');tip.className='gl-tip';tip.innerHTML='<b></b><span></span>';tip.firstChild.textContent=a.getAttribute('data-t');tip.lastChild.textContent=a.getAttribute('data-d');document.body.appendChild(tip);var r=a.getBoundingClientRect();var x=Math.min(window.innerWidth-tip.offsetWidth-12,Math.max(12,r.left+window.scrollX));tip.style.left=x+'px';tip.style.top=(r.bottom+window.scrollY+8)+'px'}
  function hide(){if(tip){tip.remove();tip=null}}
  a.addEventListener('mouseenter',show);a.addEventListener('mouseleave',hide);a.addEventListener('focus',show);a.addEventListener('blur',hide);
});

/* Recherche */
var idx=null,sr=null,sel=-1;
function closeSearch(){if(sr)sr.classList.remove('open')}
function openSearch(){
  if(!sr){sr=document.createElement('div');sr.id='sr';sr.innerHTML='<div class="box"><input class="field" type="search" placeholder="Rechercher une plante, un pays, une question…" aria-label="Rechercher"><ul></ul><div class="hint">Entrée pour ouvrir, Échap pour fermer</div></div>';document.body.appendChild(sr);
    sr.addEventListener('click',function(e){if(e.target===sr)closeSearch()});
    var inp=$('input',sr),ul=$('ul',sr);
    inp.addEventListener('input',function(){render(inp.value)});
    inp.addEventListener('keydown',function(e){var as=$$('a',ul);if(e.key==='ArrowDown'){sel=Math.min(as.length-1,sel+1);e.preventDefault()}else if(e.key==='ArrowUp'){sel=Math.max(0,sel-1);e.preventDefault()}else if(e.key==='Enter'&&as.length){location.href=as[Math.max(0,sel)].href;return}else return;as.forEach(function(a,i){a.classList.toggle('sel',i===sel)});if(as[sel])as[sel].scrollIntoView({block:'nearest'})});
    function render(q){sel=-1;ul.innerHTML='';q=norm(q.trim());if(!q||!idx)return;var ws=q.split(/\s+/);var res=[];idx.forEach(function(it){var t=norm(it.t),b=norm(it.k);var sc=0;for(var i=0;i<ws.length;i++){var w=ws[i];if(t.indexOf(w)>-1)sc+=t.indexOf(w)===0?6:4;else if(b.indexOf(w)>-1)sc+=1;else return}res.push([sc,it])});res.sort(function(a,b){return b[0]-a[0]});res.slice(0,30).forEach(function(r){var li=document.createElement('li');var a=document.createElement('a');a.href=ROOT+r[1].u;a.textContent=r[1].t;var s=document.createElement('small');s.textContent=r[1].s;a.appendChild(s);li.appendChild(a);ul.appendChild(li)});if(!res.length){ul.innerHTML='<li class="hint">Aucun résultat. Essayez un autre mot.</li>'}}
    fetch(ROOT+'assets/search.json').then(function(r){return r.json()}).then(function(j){idx=j;render(inp.value)});
  }
  sr.classList.add('open');setTimeout(function(){$('input',sr).focus()},30);
}
$$('[data-search]').forEach(function(b){b.addEventListener('click',function(e){e.preventDefault();openSearch()})});
document.addEventListener('keydown',function(e){if(e.key==='/'&&!/input|textarea/i.test((document.activeElement||{}).tagName||'')){e.preventDefault();openSearch()}});

/* Formulaire de contact */
$$('form.contact').forEach(function(f){f.addEventListener('submit',function(e){e.preventDefault();var st=$('.status',f),btn=$('button[type=submit]',f);st.className='status';btn.disabled=true;btn.textContent='Envoi…';
  fetch('/contact.php',{method:'POST',body:new FormData(f)}).then(function(r){return r.json()}).then(function(j){if(j.ok){st.className='status ok';st.textContent='Merci, votre message est bien parti. Nous vous répondons rapidement.';f.reset()}else{st.className='status err';st.textContent=j.error||"L'envoi a échoué."}}).catch(function(){st.className='status err';st.textContent="L'envoi a échoué. Vous pouvez écrire directement à contact@amourkorat.com."}).then(function(){btn.disabled=false;btn.textContent='Envoyer le message'})})});

/* Quiz */
$$('.quiz[data-quiz]').forEach(function(box){
  var data=JSON.parse(document.getElementById(box.getAttribute('data-quiz')).textContent);
  var qs=data.questions.slice();if(data.shuffle){qs.sort(function(){return Math.random()-.5});qs=qs.slice(0,data.count||qs.length)}
  var i=0,score=0,mode=data.mode||'score',tally={};
  function draw(){
    if(i>=qs.length)return end();
    var q=qs[i];box.innerHTML='<div class="bar"><i style="width:'+(i/qs.length*100)+'%"></i></div><span class="kicker">Question '+(i+1)+' sur '+qs.length+'</span><div class="q"></div><div class="opts"></div><div class="expl"></div><div class="foot"><span class="chip">'+(mode==='score'?'Score : '+score:'Prenez votre temps')+'</span><button class="btn btn-primary next" style="display:none">Suivante</button></div>';
    $('.q',box).textContent=q.q;
    q.o.forEach(function(o,k){var b=document.createElement('button');b.className='opt';b.textContent=o.t||o;b.addEventListener('click',function(){
      if(mode==='profil'){Object.keys(o.p||{}).forEach(function(c){tally[c]=(tally[c]||0)+o.p[c]});i++;draw();return}
      $$('.opt',box).forEach(function(x){x.disabled=true});var ok=k===q.a;if(ok)score++;b.classList.add(ok?'good':'bad');$$('.opt',box)[q.a].classList.add('good');
      var ex=$('.expl',box);ex.innerHTML='';var p=document.createElement('p');p.textContent=(ok?'Exact. ':'Pas tout à fait. ')+(q.e||'');ex.appendChild(p);if(q.l){var a=document.createElement('a');a.href=ROOT+q.l;a.textContent='En savoir plus';ex.appendChild(a)}ex.style.display='block';
      $('.chip',box).textContent='Score : '+score;var n=$('.next',box);n.style.display='inline-flex';n.textContent=i+1<qs.length?'Suivante':'Voir mon résultat';n.onclick=function(){i++;draw()};n.focus()
    });$('.opts',box).appendChild(b)});
  }
  function end(){
    if(mode==='profil'){var best=null;Object.keys(tally).forEach(function(c){if(best===null||tally[c]>tally[best])best=c});var r=data.results[best]||data.results[Object.keys(data.results)[0]];box.innerHTML='<span class="kicker">Votre résultat</span><div class="q"></div><div class="expl" style="display:block"></div><div class="foot"><button class="btn btn-ghost again">Recommencer</button><a class="btn btn-primary" href="'+ROOT+'contact.html">Nous écrire</a></div>';$('.q',box).textContent=r.t;$('.expl',box).textContent=r.d;}
    else{var pc=Math.round(score/qs.length*100);var msg=pc>=80?data.top:pc>=50?data.mid:data.low;box.innerHTML='<span class="kicker">Résultat</span><div class="score">'+score+' / '+qs.length+'</div><p class="q" style="font-size:1.3rem"></p><div class="foot"><button class="btn btn-ghost again">Rejouer</button><a class="btn btn-primary" href="'+ROOT+'quiz/index.html">Autres quiz</a></div>';$('.q',box).textContent=msg}
    $('.again',box).addEventListener('click',function(){i=0;score=0;tally={};if(data.shuffle)qs=data.questions.slice().sort(function(){return Math.random()-.5}).slice(0,data.count||data.questions.length);draw()});
  }
  draw();
});

/* Explorateur de plantes / pays */
$$('[data-filter-list]').forEach(function(wrap){
  var list=document.getElementById(wrap.getAttribute('data-filter-list'));var items=$$('[data-k]',list);var q=$('input[type=search]',wrap);var lvl='',letter='';var cnt=$('.count',wrap);
  function apply(){var s=norm(q?q.value:'');var n=0;items.forEach(function(it){var ok=(!s||norm(it.getAttribute('data-k')).indexOf(s)>-1)&&(!lvl||it.getAttribute('data-l')===lvl)&&(!letter||norm(it.getAttribute('data-k')).charAt(0)===letter);it.style.display=ok?'':'none';if(ok)n++});if(cnt)cnt.textContent=n+(n>1?' résultats':' résultat')}
  if(q)q.addEventListener('input',apply);
  $$('[data-lvl]',wrap).forEach(function(b){b.addEventListener('click',function(){lvl=b.getAttribute('data-lvl');$$('[data-lvl]',wrap).forEach(function(x){x.setAttribute('aria-pressed',x===b)});apply()})});
  $$('[data-letter]',wrap).forEach(function(b){b.addEventListener('click',function(){var l=b.getAttribute('data-letter');letter=letter===l?'':l;$$('[data-letter]',wrap).forEach(function(x){x.setAttribute('aria-pressed',x.getAttribute('data-letter')===letter)});apply()})});
  var h=location.hash.replace('#q=','');if(h&&q){q.value=decodeURIComponent(h);}
  apply();
});

/* Calculateur de mise bas */
$$('.calc[data-gest]').forEach(function(c){var d=$('input[type=date]',c),o=$('.out',c);function up(){if(!d.value){o.textContent='';return}var t=new Date(d.value+'T12:00:00');function add(n){var x=new Date(t);x.setDate(x.getDate()+n);return x.toLocaleDateString('fr-FR',{weekday:'long',day:'numeric',month:'long',year:'numeric'})}o.innerHTML='';var p=document.createElement('p');p.textContent='Mise bas la plus probable entre le '+add(63)+' et le '+add(65)+'.';var p2=document.createElement('p');p2.className='src';p2.textContent='Fourchette extrême : du '+add(58)+' au '+add(72)+'.';o.appendChild(p);o.appendChild(p2)}d.addEventListener('input',up)});
})();
